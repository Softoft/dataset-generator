import asyncio

from ticket_generator.ticket_generator import TicketGenerator

if __name__ == '__main__':
    ticket_generator = TicketGenerator(2_000, "../data/training/dataset-v3_6_0-1k.json",  5)
    asyncio.run(ticket_generator.generate_dataset())
